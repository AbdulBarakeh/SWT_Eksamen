namespace RouletteGame.Output
{
    public interface IOutput
    {
        void Report(string arg);
    }
}